module.exports = {
  title: 'Hello VuePress',
  description: 'Just playing around',
  dest: 'vuepress',
  base: 'vuepress',
  head: [
    ['link', { rel: 'icon', href: '/logo.png' }]
  ]
}
