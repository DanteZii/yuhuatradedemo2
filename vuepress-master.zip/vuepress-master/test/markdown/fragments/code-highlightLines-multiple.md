``` js {1-2,4-5}
const app = new Vue({
  render,
  router
})

app.$mount('#app')
```
